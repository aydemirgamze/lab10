package com.example.labb10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import static com.example.labb10.R.id.cardView1;

public class Adapter extends RecyclerView.Adapter<Adapter.CardViewTasarim>{

    private Context mContext;
    private List<String> recipes;

    public Adapter(Context mContext, List<String> recipes) {
        this.mContext = mContext;
        this.recipes = recipes;
    }

    public class CardViewTasarim extends RecyclerView.ViewHolder{
        public TextView baslik;
        public TextView body;
        public CardView cardView1;

        public CardViewTasarim(View view){
            super(view);
            baslik=view.findViewById(R.id.baslik);
            body=view.findViewById(R.id.body);
            cardView1=view.findViewById(R.id.cardView1);
        }
    }

    @NonNull
    @Override
    public CardViewTasarim onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_of_recipe,parent,false);


        return new CardViewTasarim(itemView);//cardviewtasarim sınıfından bir nesne oluşturuyoruz
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewTasarim holder, int position) {
        //kaç tane veri varsa o kadar çalışıyor
        String recipe=recipes.get(position);
        holder.baslik.setText(recipe);

        holder.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

    }

    @Override
    public int getItemCount() {
        return recipes.size();
    }


}
